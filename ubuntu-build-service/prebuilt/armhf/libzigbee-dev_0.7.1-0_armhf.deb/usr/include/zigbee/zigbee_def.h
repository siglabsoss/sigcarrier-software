#ifndef	__ZIGBEE_DEF_H__
#define	__ZIGBEE_DEF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "zigbee_clusters.h"

/*! \file zigbee_def.h
 *
 *	\brief ZigBee definitions
 *
 *	Definitions and functions
 *
 */
#define REQUIRED_ZIGBEED_VERSION		"0.7.1"
#define ZIGBEED_VERSION_FILE			"/etc/zigbee/daemon_version"
#define ZIGBEED_PROCESS_NAME			"zigbeed"

/* why we not use profile id directly.
 * for most device type of ZLL, the profile id is 0x104, same to HA.
 * for more information, please check [UG1039-AppDevFundamentals-ZLL.pdf],
 * chapter [3.1 Clusters]. GP have same problem.
 */
typedef unsigned short ZIGBEE_PROFILE;
#define ZIGBEE_PROFILE_HA	0x0104
#define ZIGBEE_PROFILE_ZLL	0xC05E
#define ZIGBEE_PROFILE_GP	0xA1E0

typedef unsigned short ZIGBEE_DEVICEID;
#define DEVICE_ON_OFF_SWITCH			0x0000
#define DEVICE_LEVEL_CONTROL_SWITCH		0x0001
#define DEVICE_REMOTE_CONTROL			0x0006
#define DEVICE_ON_OFF_LIGHT				0x0100
#define DEVICE_DIMMABLE_LIGHT			0x0101
#define DEVICE_COLOR_DIMMABLE_LIGHT		0x0102
#define DEVICE_ON_OFF_LIGHT_SWITCH		0x0103
#define DEVICE_DIMMER_SWITCH			0x0104
#define DEVICE_COLOR_DIMMER_SWITCH		0x0105
#define DEVICE_LIGHT_SENSOR				0x0106
#define DEVICE_OCCUPANCY_SENSOR			0x0107
#define DEVICE_HEATING_COOLING_UNIT		0x0300
#define DEVICE_THERMOSTAT				0x0301
#define DEVICE_TEMPERATURE_SENSOR		0x0302

/**
 * @brief	Type for referring to ZCL attribute id
 *			For the attribute ids, please check zigbee_attributes.h
 */
typedef	unsigned short		ZIGBEE_ATTRIBUTE_ID;
#define	MAX_ATTRIBUTE_ID	0xFFFE

/**
 * @brief	Type for referring to ZCL cluster id
 *			For the cluster ids, please check zigbee_clusters.h
 */
typedef	unsigned short		ZIGBEE_CLUSTER_ID;
#define	MAX_CLUSTER_ID		0xFFFE

#define	MAX_COMMAND_BUFFER_SIZE	5000
#define MAX_RESPONSE_SIZE		10000
#define MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH	1024
#define MAX_DEVICE_INFO_SIZE	20
#define MAX_ENDPOINT_SIZE		5
#define MAX_CLUSTER_SIZE		9
#define EUI64_SIZE				8
#define COORDINATOR_NODEID		0x0000
#define ZIGBEE_BROADCAST_ENDPOINT	0xFF
#define MAX_BINDING_TABLE_SIZE		5

#define ILLUMINANCE_MAX_VALUE					0xfffe
#define ILLUMINANCE_MIN_VALUE					1
#define ILLUMINANCE_VALUE_TOO_LOW_BE_MEASSURED	0
#define ILLUMINANCE_INVALIED_VALUE				0xffff
#define ILLUMINANCE_MAX_THRESHOLD				(ILLUMINANCE_MAX_VALUE - ILLUMINANCE_MIN_VALUE)

#define TEMPERATURE_MAX_VALUE					0x7fff
#define TEMPERATURE_MIN_VALUE					(0x954d - 1 - 0xffff)
#define TEMPERATURE_INVALID_VALUE				0x8000
#define TEMPERATURE_MAX_THRESHOLD				(TEMPERATURE_MAX_VALUE - TEMPERATURE_MIN_VALUE)

/**
 * Error code
 */
#define EZ_OK					(0)
#define EZ_ERROR				(-1)
#define EZ_BAD_ARGS				(-2)
#define EZ_NOT_INITIALIZED		(-3)
#define EZ_NO_MEM				(-4)
#define EZ_NOT_SUPPORTED		(-5)
#define EZ_INVALID_VALUE		(-6)
#define EZ_INVALID_DAEMON		(-7)
#define EZ_NO_DAEMON			(-8)
#define EZ_NO_MESSAGE			(-9)
#define EZ_INVALID_ATTR			(-10)
#define EZ_NO_DEVICE			(-11)
#define EZ_ERR_SOCK				(-12)
#define EZ_MSG_SEND_ERROR		(-13)
#define EZ_NETWORK_EXIST		(-14)

/*!
 * \brief	The max attribute value size
 */
#define MAX_ATTRIBUTE_SIZE	16

/*!
 * \brief	Receiving command notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_CMD_SUCCESS = 0,
	ZIGBEE_CMD_ERR_PORT_PROBLEM = -3001,
	ZIGBEE_CMD_ERR_NO_SUCH_COMMAND = -3002,
	ZIGBEE_CMD_ERR_WRONG_NUMBER_OF_ARGUMENTS = -3003,
	ZIGBEE_CMD_ERR_ARGUMENT_OUT_OF_RANGE = -3004,
	ZIGBEE_CMD_ERR_ARGUMENT_SYNTAX_ERROR = -3005,
	ZIGBEE_CMD_ERR_STRING_TOO_LONG = -3006,
	ZIGBEE_CMD_ERR_INVALID_ARGUMENT_TYPE = -3007,
	ZIGBEE_CMD_ERR = -3008
} zigbee_notification;
/*!
 * \brief	Receiving network notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	/* It is notified in coordinator side when router joins current network */
	ZIGBEE_NETWORK_JOIN = 3100,
	/* It is notified in coordinator side when router leaves current network */
	ZIGBEE_NETWORK_LEAVE,
	ZIGBEE_NETWORK_FIND_FORM_SUCCESS,
	ZIGBEE_NETWORK_FIND_FORM_FAILED,
	ZIGBEE_NETWORK_FIND_JOIN_SUCCESS,
	ZIGBEE_NETWORK_FIND_JOIN_FAILED,
	/* If it is in a network currently and form/join is re-called, this type
	 * notification will be used*/
	ZIGBEE_NETWORK_EXIST,
	/* It is used when network_form_manually */
	ZIGBEE_NETWORK_FORM_SUCCESS,
	ZIGBEE_NETWORK_FORM_FAILED,
	/* It is used when network_join_manually */
	ZIGBEE_NETWORK_JOIN_SUCCESS,
	ZIGBEE_NETWORK_JOIN_FAILED
} zigbee_network_notification;
/*!
 * \brief	Receiving node type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_UNKNOWN_DEVICE = 3200,
	ZIGBEE_COORDINATOR = 3201,
	ZIGBEE_ROUTER = 3202,
	ZIGBEE_END_DEVICE = 3203,
	ZIGBEE_SLEEPY_END_DEVICE = 3204
} zigbee_node_type;
/*!
 * \brief	Receiving network state from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_NO_NETWORK = 3210,
	ZIGBEE_JOINING_NETWORK,
	ZIGBEE_JOINED_NETWORK,
	ZIGBEE_JOINED_NETWORK_NO_PARENT,
	ZIGBEE_LEAVING_NETWORK
} zigbee_network_state;
/*!
 * \brief	Device discovery result
 */
typedef enum {
	ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE = 3220,
	ZIGBEE_DEVICE_DISCOVERY_FOUND,
	ZIGBEE_DEVICE_DISCOVERY_DONE,
	ZIGBEE_DEVICE_DISCOVERY_START,
	ZIGBEE_DEVICE_DISCOVERY_ERROR,
	ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS,/* Cyclic discovery is in progress or last calling is not finished */
	ZIGBEE_DEVICE_DISCOVERY_CHANGED,	/* In cycle discovery, device is changed */
	ZIGBEE_DEVICE_DISCOVERY_LOST		/* In cycle discovery, device is lost */
} zigbee_device_discovery_status;
/*!
 * \brief	Network find status
 */
typedef enum {
	ZIGBEE_NETWORK_FOUND = 3230,
	ZIGBEE_NETWORK_FIND_FINISHED,
	ZIGBEE_NETWORK_FIND_ERR
} zigbee_network_find_status;

typedef enum {
	ZIGBEE_SERVICE_DISCOVERY_RECEIVED = 3240,
	ZIGBEE_SERVICE_DISCOVERY_DONE,
	ZIGBEE_SERVICE_DISCOVERY_ERROR
} zigbee_service_discovery_result;
/*!
 * \brief	Receiving response type from ZigBee Daemon
 */
typedef enum {
	/* Common response */
	ZIGBEE_RESPONSE_NOTIFICATION = 3300,
	ZIGBEE_RESPONSE_CLIENT_TO_SERVER_COMMAND_RECEIVED,
	ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE,
	ZIGBEE_RESPONSE_REPORTING_CONFIGURE,
	ZIGBEE_RESPONSE_REPORT_ATTRIBUTE,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_START,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_STOP,
	/* Network response */
	ZIGBEE_RESPONSE_NETWORK_NOTIFICATION,
	ZIGBEE_RESPONSE_NETWORK_FIND,
	/* Device response */
	ZIGBEE_RESPONSE_DEVICE_DISCOVER,
	/* Cluster response */
	ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY,
	ZIGBEE_RESPONSE_GROUPS_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_STATUS,
	ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_BOUND_INFO,
	ZIGBEE_RESPONSE_IEEE_ADDR_RESP,
	ZIGBEE_RESPONSE_SIMPLE_DESC_RESP,
	ZIGBEE_RESPONSE_MATCH_DESC_RESP,
	ZIGBEE_RESPONSE_BASIC_RESET_TO_FACTORY,	/* < Received basic reset to factory defaults requesting */
	ZIGBEE_RESPONSE_LEVEL_CONTROL,
	/* Common response none */
	ZIGBEE_RESPONSE_NONE
} zigbee_response_type;
/*!
 * \brief	Attribute change type
 */
typedef enum {
	ZIGBEE_ATTR_ONOFF_STATUS,
	ZIGBEE_ATTR_LEVELCONTROL_LEVEL,
	ZIGBEE_ATTR_COLOR_HUE,
	ZIGBEE_ATTR_COLOR_SATURATION,
	ZIGBEE_ATTR_COLOR_CURRENT_X,
	ZIGBEE_ATTR_COLOR_CURRENT_Y,
	ZIGBEE_ATTR_COLOR_TEMP,
	ZIGBEE_ATTR_FAN_MODE,
	ZIGBEE_ATTR_FAN_MODE_SEQUENCE,
	ZIGBEE_ATTR_OCCUPIED_HEATING_SETPOINT,
	ZIGBEE_ATTR_OCCUPIED_COOLING_SETPOINT,
	ZIGBEE_ATTR_SYSTEM_MODE,
	ZIGBEE_ATTR_CONTROL_SEQUENCE,
	ZIGBEE_ATTR_ILLUMINANCE,	/* cls:0x0400, attr:0x0000 */
	ZIGBEE_ATTR_TEMPERATURE,	/* cls:0x0402, attr:0x0000 */
	ZIGBEE_ATTR_OCCUPANCY,		/* cls:0x0406, attr:0x0000 */
	ZIGBEE_ATTR_THERMOSTAT_TEMPERATURE,	/* cls:0x0201, attr:0x0000 */
	ZIGBEE_ATTR_NONE
} zigbee_attribute_type;
/*!
 * \brief	Selectable tx power level
 */
typedef enum {
	ZIGBEE_TX_POWER_8 = 8,
	ZIGBEE_TX_POWER_7 = 7,
	ZIGBEE_TX_POWER_6 = 6,
	ZIGBEE_TX_POWER_5 = 5,
	ZIGBEE_TX_POWER_4 = 4,
	ZIGBEE_TX_POWER_3 = 3,
	ZIGBEE_TX_POWER_2 = 2,
	ZIGBEE_TX_POWER_1 = 1,
	ZIGBEE_TX_POWER_0 = 0,
	ZIGBEE_TX_POWER_MINUS1 = -1,
	ZIGBEE_TX_POWER_MINUS2 = -2,
	ZIGBEE_TX_POWER_MINUS3 = -3,
	ZIGBEE_TX_POWER_MINUS4 = -4,
	ZIGBEE_TX_POWER_MINUS5 = -5,
	ZIGBEE_TX_POWER_MINUS6 = -6,
	ZIGBEE_TX_POWER_MINUS7 = -7,
	ZIGBEE_TX_POWER_MINUS8 = -8,
	ZIGBEE_TX_POWER_MINUS9 = -9,
	ZIGBEE_TX_POWER_MINUS11 = -11,
	ZIGBEE_TX_POWER_MINUS12 = -12,
	ZIGBEE_TX_POWER_MINUS14 = -14,
	ZIGBEE_TX_POWER_MINUS17 = -17,
	ZIGBEE_TX_POWER_MINUS20 = -20,
	ZIGBEE_TX_POWER_MINUS26 = -26,
	ZIGBEE_TX_POWER_MINUS43 = -43
} zigbee_tx_power;
/*!
 * \brief	Request for device attribute information reporting
 */
typedef enum {
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_THERMOSTAT_TEMPERATURE = 0,
	/*
	 * ZIGBEE_REPORTING_OCCUPANCY_SENSING for change_threshold parameter has
	 * no meaning, set change_threshold value to 0
	 * */
	ZIGBEE_REPORTING_OCCUPANCY_SENSING,
	/*
	 * The change_threshold should be in the range 0 ~ 65533
	 * */
	ZIGBEE_REPORTING_MEASURED_ILLUMINANCE,
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_MEASURED_TEMPERATURE
} zigbee_reporting_type;
/*!
 * \brief Local endpoint
 */
typedef struct {
	ZIGBEE_PROFILE profile;
	int endpoint_id;
	ZIGBEE_DEVICEID device_id;
} zigbee_local_endpoint;
/*!
 * \brief Local endpoint information
 */
typedef struct {
	int count;
	zigbee_local_endpoint endpoints[MAX_ENDPOINT_SIZE];
} zigbee_local_endpoint_info;
/*!
 * \brief	Structure for endpoint information
 */
typedef struct {
	int endpoint_id;
	int node_id;
	ZIGBEE_DEVICEID device_id;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_endpoint;
/*!
 * \brief	Structure for endpoint list to find endpoints by cluster ID
 */
typedef struct {
	int num;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE * MAX_DEVICE_INFO_SIZE];
} zigbee_endpoint_list;
/*!
 * \brief	Structure for device information
 *			This is used when sending cluster commands to select device
 */
typedef struct {
	char eui64[EUI64_SIZE];
	int node_id;
	int endpoint_count;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE];
} zigbee_device;
/*!
 * \brief	List of device information
 */
typedef struct {
	int num;
	zigbee_device device[MAX_DEVICE_INFO_SIZE];
} zigbee_device_info;
/*!
 * \brief	Device discovery response
 */
typedef struct {
	zigbee_device_discovery_status status;
	zigbee_device device;
} zigbee_device_discovery;
/*!
 * \brief	Structure for network information
 */
typedef struct {
	int channel;
	zigbee_tx_power tx_power;
	int pan_id;
} zigbee_network_info;
/*!
 * \brief	Network find result
 */
typedef struct {
	zigbee_network_find_status find_status;
	zigbee_network_info network_info;
} zigbee_network_find_result;
/*!
 * \brief	Received command from remote device
 */
typedef struct {
	bool is_global_command;
	int dest_endpoint_id;
	int cluster_id;
	int command_id;
	char payload[MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH];
	int payload_length;	/* -1 if buffer size isn't enough */
	int source_node_id;
	int source_endpoint_id;
} zigbee_received_command;
/*!
 * \brief	Attribute changed response from zigbeed
 */
typedef struct {
	zigbee_attribute_type type;
	int endpoint_id;
} zigbee_attribute_changed_response;

/*!
 * \brief	A structure used to store reporting configurations. If endpoint
 *			field is ::EMBER_AF_PLUGIN_REPORTING_UNUSED_ENDPOINT_ID, this
 *			configure is unused.
 */
typedef struct {
	bool used;
	int endpoint_id;
	int cluster_id;
	int attribute_id;
	bool is_server;

	struct {
		/** The minimum reporting interval, measured in seconds. */
		uint16_t min_interval;
		/** The maximum reporting interval, measured in seconds. */
		uint16_t max_interval;
		/** The minimum change to the attribute that will result in a report
		 *  being sent.
		 */
		uint32_t reportable_change;
	} reported;
} zigbee_reporting_info;

/*!
 * \brief	Structure for report attribute from remote server
 */
typedef struct {
	zigbee_attribute_type attribute_type;
	union {
		int value;
		zigbee_occupancy_status occupancy;
	} data;
} zigbee_report_attribute_info;

/*!
 * \brief	A structure for notifying identify feedback.
 */
typedef struct {
	int endpoint_id;
	int duration;	/* in seconds */
} zigbee_identify_feedback_info;

/*!
* \brief	Structure of target that ezmode commissioning find
*			Used in callback, to notify user
 */
typedef struct {
	int node_id;
	int endpoint_id;
} zigbee_commissioning_target_info;

/*!
* \brief	Structure of clusters that bound by ezmode commissioning
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int cluster_id;
	int endpoint_id;
} zigbee_commissioning_bound_info;

/*!
* \brief	Commissioning state
*			Used in callback, to notify user
*/
typedef enum {
	COMMISSIONING_ERROR = 0x00,				/* < Commissioning error */
	COMMISSIONING_ERR_IN_PROGRESS,			/* < Commissioning in progress error */
	COMMISSIONING_NETWORK_STEERING_FORM,	/* < Try to form a new network if network join failed */
	COMMISSIONING_NETWORK_STEERING_SUCCESS,	/* < Network steering successfully */
	COMMISSIONING_NETWORK_STEERING_FAILED,	/* < Network steering failed */
	COMMISSIONING_WAIT_NETWORK_STEERING,	/* < Network steering is in progress, wait */
	COMMISSIONING_TARGET_SUCCESS,			/* < Commissioning target successfully */
	COMMISSIONING_TARGET_STOP,				/* < Commissioning target stopped */
	COMMISSIONING_TARGET_FAILED,			/* < Commissioning target failed */
	COMMISSIONING_INITIATOR_SUCCESS,		/* < Commissioning initiator successfully */
	COMMISSIONING_INITIATOR_STOP,			/* < Commissioning initiator stopped */
	COMMISSIONING_INITIATOR_FAILED			/* < Commissioning initiator failed */
} zigbee_commissioning_state;

/*!
* \brief	Simple descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int target_node_id;
	int target_endpoint;
	int server_cluster_count;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster_count;
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_simple_descriptor_response;

/*!
* \brief	Broadcast identify query response
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int endpoint_id;
	int timeout;
} zigbee_broadcast_identify_query_response;

/*!
* \brief	Ieee addr response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	char eui64[EUI64_SIZE];
} zigbee_ieee_addr_response;

/*!
* \brief	Match descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	int endpoint_list[MAX_ENDPOINT_SIZE];
	int count;
} zigbee_match_desc_response;

/*!
* \brief	End device bind response
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int status;
} zigbee_end_device_bind_response;

/*!
* \brief Zigbee binding type
*/
typedef enum {
	/* A binding that is currently not in use. */
	ZIGBEE_UNUSED_BINDING	 = 0,
	/* A unicast binding whose 64-bit identifier is the destination EUI64. */
	ZIGBEE_UNICAST_BINDING	 = 1,
	/* A unicast binding whose 64-bit identifier is the many-to-one
	 * destination EUI64.  Route discovery should be disabled when sending
	 * unicasts via many-to-one bindings.
	 */
	ZIGBEE_MANY_TO_ONE_BINDING	 = 2,
	/* A multicast binding whose 64-bit identifier is the group address. A
	 * multicast binding can be used to send messages to the group and to receive
	 * messages sent to the group.
	 */
	ZIGBEE_MULTICAST_BINDING	 = 3
} zigbee_binding_type;

/*!
* \brief Zigbee binding table entry
*/
typedef struct {
	/* The type of binding. */
	zigbee_binding_type type;
	/*The endpoint on the local node.*/
	int local;
	/* A cluster ID that matches one from the local endpoint's simple descriptor.
	 * This cluster ID is set by the provisioning application to indicate which
	 * part an endpoint's functionality is bound to this particular remote node
	 * and is used to distinguish between unicast and multicast bindings. Note
	 * that a binding can be used to to send messages with any cluster ID, not
	 * just that listed in the binding.
	 */
	int cluster_id;
	/* The endpoint on the remote node (specified by \c identifier).*/
	int remote;
	/* A 64-bit identifier.  This is either:
	 * - The destination EUI64, for unicasts
	 * - A 16-bit multicast group address, for multicasts
	 */
	char identifier[EUI64_SIZE];
	/* The index of the network the binding belongs to.*/
	int network_index;
} zigbee_binding_table_entry;

/*!
 * \brief	endpoint instance
 */
typedef void *zigbee_endpoint_handle;

/**
 * @brief	Used to store endpoint info, get this info by
 *			get_device_info_by_handle()
 * @see		get_device_info_by_handle
 */
struct inner_endpoint_info {
	int endpoint_id;
	ZIGBEE_PROFILE profile;
	ZIGBEE_DEVICEID device_id;
	unsigned char version;
};

#ifdef __cplusplus
}
#endif
#endif				/* __ZIGBEE_DEF_H__ */
